
package model;


public class Raca {
    private int ID_RACA;
    private String DS_RACA;
    private boolean TG_INATIVO;

    public int getID_RACA() {
        return ID_RACA;
    }

    public void setID_RACA(int ID_RACA) {
        this.ID_RACA = ID_RACA;
    }

    public String getDS_RACA() {
        return DS_RACA;
    }

    public void setDS_RACA(String DS_RACA) {
        this.DS_RACA = DS_RACA;
    }

    public boolean isTG_INATIVO() {
        return TG_INATIVO;
    }

    public void setTG_INATIVO(boolean TG_INATIVO) {
        this.TG_INATIVO = TG_INATIVO;
    }
    
}
