package controller;

public class VendaDao extends ConectarDao {
    private String sql;
    
    public VendaDao(){
        super();
    }
}