package controller;

public class AtendimentoServicoDao extends ConectarDao {
    private String sql;
    
    public AtendimentoServicoDao(){
        super();
    } 
}