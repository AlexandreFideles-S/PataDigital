package controller;

public class AtendimentoDao extends ConectarDao {
    private String sql;
    
    public AtendimentoDao(){
        super();
    }
}