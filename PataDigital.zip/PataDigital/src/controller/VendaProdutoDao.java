package controller;

public class VendaProdutoDao extends ConectarDao {
    private String sql;
    
    public VendaProdutoDao(){
        super();
    }
}