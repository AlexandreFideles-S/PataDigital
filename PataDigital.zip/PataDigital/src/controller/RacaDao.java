package controller;

public class RacaDao extends ConectarDao {
    private String sql;
    
    public RacaDao(){
        super();
    }
}