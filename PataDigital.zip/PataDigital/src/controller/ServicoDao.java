package controller;

public class ServicoDao extends ConectarDao {
    private String sql;
    
    public ServicoDao() { 
        super(); 
    }
}