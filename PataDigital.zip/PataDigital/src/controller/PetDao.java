package controller;

public class PetDao extends ConectarDao {
    private String sql;
    
    public PetDao(){
        super();
    } 
}