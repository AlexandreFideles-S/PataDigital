package controller;

public class FormaPagamentoDao extends ConectarDao {
    private String sql;
    
    public FormaPagamentoDao(){
        super();
    }
}