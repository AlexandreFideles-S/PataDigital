package controller;

public class ProdutoDao extends ConectarDao {
    private String sql;
    
    public ProdutoDao(){
        super();
    }
}